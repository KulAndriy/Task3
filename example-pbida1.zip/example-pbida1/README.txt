This is an example framework.

If you will have issues with Installing and Running - please contact Maryna Pashchenko.