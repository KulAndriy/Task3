package com.epam.training.framework.core.interfaces.elements;

public interface IButton extends IElement {
    void click();
}
