package com.epam.training.framework.core.interfaces.elements;

public interface ILink extends IElement{

}
