package com.epam.training.framework.enums;

public enum LogType {
    INFO, ERROR, WARNING;
}
