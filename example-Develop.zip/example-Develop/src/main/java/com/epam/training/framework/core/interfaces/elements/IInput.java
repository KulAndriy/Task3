package com.epam.training.framework.core.interfaces.elements;

public interface IInput extends IElement{
    void write(String str);
}
